# chatbotapp-gui
Chatbot in python using tkinter module that will calculate mathematical expressions
